// Interactivity demo 1

// testing it out 
console.log("just making sure this works")



//invert
var invertButton = document.querySelector('.bg-color')
var bodyClass = document.body.classList

invertButton.addEventListener('click', changeColor)

function changeColor() {
    bodyClass.add('invert')
}


